#!/bin/bash

# Vérifier si le script est exécuté en tant que root
if [ "$EUID" -ne 0 ]; then
  echo "Erreur : Ce script doit être exécuté en tant que root." >&2
  exit 1
fi
apt update && apt install -y mumble-server

sudo touch /var/lib/mumble-server/murmur.sqlite
sudo chown mumble-server:mumble-server /var/lib/mumble-server/murmur.sqlite

sudo cp ./etc/murmur.ini /etc/mumble-server.ini

sudo dpkg-reconfigure mumble-server

echo ""
echo "Installation de mumble-server effectuée avec succès !"
echo ""

sudo apt install -y build-essential gcc g++ python3-dev
sudo apt install -y libssl-dev libbz2-dev
python3 -m pip install --upgrade pip setuptools wheel

python3 -m venv venv
source venv/bin/activate
pip install zeroc-ice
pip install flask
pip install flask_classfull
pip install flask_httpauth
pip install gevent
pip install greenlet
pip install gunicorn

echo "Fin de l'installation des dépendances"
exit 0