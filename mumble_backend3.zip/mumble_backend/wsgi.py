# WSGI file for Python servers (GUnicorn, UWSGI).

from app.api import app

app = app
