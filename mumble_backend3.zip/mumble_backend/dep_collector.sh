pip install zeroc-ice
pip install flask
pip install flask_classfull
pip install flask_httpauth
pip install gevent
pip install greenlet
pip install gunicorn

echo "Fin de l'installation des dépendances, vous pouvez maintenant lancer le backend s'il n'y a pas eu d'erreurs."
exit 0